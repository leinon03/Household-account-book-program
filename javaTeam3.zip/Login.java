package javaTeam3;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// 로그인
class Login extends JFrame implements ActionListener, FocusListener{
	private JTextField idField;				// 아이디 입력
	private JTextField pwField;				// 비밀번호 입력
	private JButton logjb;					// 로그인 버튼
	private JButton membershipjb;			// 회원가입 버튼
	private JLabel exjl;					// 제목
	
	// 회원DB
	private UserDB udb = new UserDB();
	
	// 로그인 UI
	public void login(){
		Container ct = getContentPane();
		setLayout(new BorderLayout());
		
		// 프로그램 이름
		JPanel ex = new JPanel();
		exjl = new JLabel( "월간 가계부", SwingConstants.CENTER);
		exjl.setFont(new Font("맑은 고딕", Font.BOLD, 30));
	    exjl.setBorder(BorderFactory.createEmptyBorder(50, 0, 30, 0));
		ex.add(exjl);
		
		// 로그인
		JPanel login = new JPanel(new GridLayout(2, 2, 2, 2));
		JLabel id = new JLabel("아이디");
		id.setFont(new Font("맑은 고딕", Font.BOLD, 15));			// 아이디 폰트
		JLabel pw = new JLabel("비밀번호");
		pw.setFont(new Font("맑은 고딕", Font.BOLD, 15));			// 비밀번호 폰트
		
		// 텍스트 필드 안내 문구
		idField = new JTextField("2자리 이상 8자리 이하", 15);		// 아이디 텍스트필드
		pwField = new JTextField("4자리 이상 20자리 이하", 15);		// 비밀번호 텍스트필드
		
		login.add(id);
		login.add(idField);
		login.add(pw);
		login.add(pwField);
		login.setBorder(BorderFactory.createEmptyBorder(50, 180, 10, 0));
		
		// 텍스트필드 이벤트
		idField.addFocusListener(this);
		pwField.addFocusListener(this);
		
		// 로그인 버튼
		JPanel logjp = new JPanel(new BorderLayout());
		logjb = new JButton("로그인");
		logjb.addActionListener(this);
		logjp.add(logjb, BorderLayout.EAST);
		logjp.setBorder(BorderFactory.createEmptyBorder(50, 10, 10, 220));
		
		// 회원가입 버튼
		JPanel membership = new JPanel(new BorderLayout());
		membershipjb = new JButton("회원가입");
		membershipjb.setBorderPainted(false);		// 버튼 테두리 제거
		membershipjb.setContentAreaFilled(false);	// 버튼 배경 제거

		// 회원가입 버튼 이벤트
		membershipjb.addActionListener(this);
		
		membership.add(membershipjb);
		membership.setBorder(BorderFactory.createEmptyBorder(0, 400, 180, 300));
		
		
		// 패널 배치
		JPanel inlogjp = new JPanel(new BorderLayout());
		inlogjp.add(login, BorderLayout.WEST);
		inlogjp.add(logjp, BorderLayout.EAST);
		inlogjp.add(membership, BorderLayout.SOUTH);
		
		// JFrame에 모든 패널 넣기
		add(ex, BorderLayout.NORTH);			// 프로그램 이름
		add(inlogjp, BorderLayout.CENTER);		// 로그인 기능
		
		setTitle("월간 가계부");
		setSize(800, 500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	// 로그인 텍스트필드 설명 이벤트
	public void focusGained(FocusEvent e) {
		// 클릭하지 않았을 때 안내 메시지
	    if (e.getSource() == idField) {
	    	if (idField.getText().equals("2자리 이상 8자리 이하")) {
	    		idField.setText("");
	        }
	    } else if (e.getSource() == pwField) {
	    	if (pwField.getText().equals("4자리 이상 20자리 이하")) {
	    		pwField.setText("");
	    	}
	    }
	}
	 
	// 로그인 텍스트필드 설명 이벤
	public void focusLost(FocusEvent e) {
		if (e.getSource() == idField) {
			// 사용자 입력 없을 시 설명 텍스트를 다시 설정
			if (idField.getText().isEmpty()) {
				idField.setText("2자리 이상 8자리 이하");
			}
		} else if (e.getSource() == pwField) {
			if (pwField.getText().isEmpty()) {
				pwField.setText("4자리 이상 20자리 이하");
			}
		}
	}
	
	// ------ 버튼 클릭 처리 ------
	public void actionPerformed(ActionEvent e) {
		 Object src = e.getSource();
	       
		// 로그인 버튼 눌렀을 때만 처리
		 if (src == logjb) { 
			 String userID = idField.getText();
			 String userPW = pwField.getText();
			 
			 // 입력 유효성 검사
			 if (userID.equals("2자리 이상 8자리 이하") || userPW.equals("4자리 이상 20자리 이하") || userID.isEmpty() || userPW.isEmpty()) {
				 JOptionPane.showMessageDialog(null, "아이디와 비밀번호를 입력해주세요.", "로그인 경고", JOptionPane.WARNING_MESSAGE);
                 return;
             }
			 
			// DB에 사용자 로그인 정보 확인
			 boolean loginCorrect = udb.loginUser(userID, userPW);
	           
			 if (loginCorrect) {
				 dispose();	// 현재 창 닫기
                 // 메인 화면 실행
				 new MonthlyLedgerFrame(userID);
			} else {
				JOptionPane.showMessageDialog(null, "아이디 또는 비빌번호가 틀렸습니다", "로그인 경고", JOptionPane.WARNING_MESSAGE);
			}
		}
		 
		// 회원가입 버튼 클릭 시
		if (src == membershipjb) {
			dispose();
			new Membership().membership(); // 회원가입 창 띄우기
		}
	}
}





