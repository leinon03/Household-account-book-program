package javaTeam3;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Locale;

// 설정 창
public class SettingsTabPanel extends JSplitPane {

    private final LedgerData data;	
    private final DefaultTableModel incomeModel;	// 수입 내역 보여주는 테이블
    private final Runnable updateCallback;			// 데이터 변경 시 메인 프레임에 알리는 콜백 함수

    // UI 컴포넌트
    private JTextField tfOverRatio; // 과소비 기준 비율 입력창
    private JTextField tfIncome;	// 수입 금액 입력창
    private JTextField tfRemain;	// 잔액 표시창
    private JComboBox<String> cbSize; // 창 크기 콤보박스

    private JTable incomeTable;		// 수입 내역 테이블

    // 버튼 컴포넌트
    private JButton btnSaveOverRatio;
    private JButton btnAddIncome;
    private JButton btnDeleteIncome;
    private JButton btnCalcRemain;
    private JButton btnExitProgram;

    // 설정 UI
    public SettingsTabPanel(LedgerData data, Runnable updateCallback) {
        super(JSplitPane.HORIZONTAL_SPLIT);
        this.data = data;
        this.incomeModel = data.getIncomeModel();
        this.updateCallback = updateCallback;

        setResizeWeight(0.3);

        // ui 구성 메서드 호출
        JPanel leftPanel = buildLeftPanel(); // 왼쪽 설정 영역
        JScrollPane rightPanel = buildRightPanel();	// 오른쪽 수입 테이블 영역

        setLeftComponent(leftPanel);
        setRightComponent(rightPanel);

        loadSettings();
        
        bindEvents();
    }
    
    // 초기 설정 값
    private void loadSettings() {
    	// 과소비 비율을 텍스트 필드에 표시
        tfOverRatio.setText(String.valueOf(data.getOverRatio()));
    }

    // 왼쪽 UI
    private JPanel buildLeftPanel() {
        JPanel left = new JPanel(new GridBagLayout());
        left.setBorder(new TitledBorder("설정"));

        GridBagConstraints c = baseConstraints();
        int y = 0;

        // 과소비 판단 (%)
        tfOverRatio = new JTextField();
        btnSaveOverRatio = new JButton("저장");
        btnSaveOverRatio.setPreferredSize(new Dimension(60, 20));

        // 텍스트 필드와 저장 버튼을 담을 패널
        JPanel overLine = new JPanel(new BorderLayout(5, 0));
        overLine.add(tfOverRatio, BorderLayout.CENTER);
        overLine.add(btnSaveOverRatio, BorderLayout.EAST);

        addLine(left, c, y++, "과소비 판단(%)", overLine);

        // 수입 입력
        tfIncome = new JTextField();
        addLine(left, c, y++, "수입", tfIncome);

        // 수입 버튼(추가/삭제)
        btnAddIncome = new JButton("추가");
        btnDeleteIncome = new JButton("삭제");

        JPanel incomeBtnLine = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 0));
        incomeBtnLine.add(btnAddIncome);
        incomeBtnLine.add(btnDeleteIncome);

        addFullWidthLine(left, c, y++, incomeBtnLine);

        // 남은 금액
        tfRemain = new JTextField();
        tfRemain.setEditable(false);
        addLine(left, c, y++, "남은 금액", tfRemain);

        // 남은 금액 계산 버튼
        btnCalcRemain = new JButton("남은 금액 계산");
        addFullWidthLine(left, c, y++, btnCalcRemain);

        // 크기 선택
        cbSize = new JComboBox<>(new String[]{
                "800 x 500", "900 x 600", "1200 x 700", "1600 x 900", "1920 x 1080"
        });
        addLine(left, c, y++, "크기", cbSize);

        // 종료
        btnExitProgram = new JButton("프로그램 종료");
        addFullWidthLine(left, c, y, btnExitProgram);

        return left;
    }
    
    // 오른쪽 UI
    private JScrollPane buildRightPanel() {
        incomeTable = new JTable(incomeModel);
        incomeTable.setFillsViewportHeight(true);

        JScrollPane scroll = new JScrollPane(incomeTable);
        scroll.setBorder(new TitledBorder("수입 목록"));

        return scroll;
    }
    
    // 이벤트 바인딩
    private void bindEvents() {
    	btnSaveOverRatio.addActionListener(e -> handleSaveOverRatio());
        btnAddIncome.addActionListener(e -> handleAddIncome());
        btnDeleteIncome.addActionListener(e -> handleDeleteIncome());
        btnCalcRemain.addActionListener(e -> handleCalcRemain());
        cbSize.addActionListener(e -> handleChangeSize());
        
        // 프로그램 종료 이벤트
        btnExitProgram.addActionListener(e -> System.exit(0));
        tfIncome.addActionListener(e -> handleAddIncome());
    }
    
    private GridBagConstraints baseConstraints() {
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.anchor = GridBagConstraints.WEST;
        c.weightx = 1.0;
        return c;
    }
    
    // ------- 유틸리티 메서드 -------
    private void addLine(JPanel parent, GridBagConstraints c, int y, String label, Component comp) {
        c.gridx = 0;
        c.gridy = y;
        c.weightx = 0;
        c.gridwidth = 1;
        parent.add(new JLabel(label), c);

        c.gridx = 1;
        c.weightx = 1.0;
        parent.add(comp, c);
    }

    private void addFullWidthLine(JPanel parent, GridBagConstraints c, int y, Component comp) {
        c.gridx = 0;
        c.gridy = y;
        c.gridwidth = 2;
        c.weightx = 1.0;
        parent.add(comp, c);
        c.gridwidth = 1;
    }
    
    // 과소비 기준 비율 저장 로직
    private void handleSaveOverRatio() {
        String over = tfOverRatio.getText().trim();
        if (over.isEmpty()) return;

        try {
            double ratio = Double.parseDouble(over);
            if (ratio < 0) {
                JOptionPane.showMessageDialog(this, "0 이상의 값을 입력하세요.");
                return;
            }
            data.setOverRatio(ratio);
            JOptionPane.showMessageDialog(this, "과소비 판단 비율이 " + ratio + "% 로 저장되었습니다.");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "유효한 숫자를 입력하세요.");
        }
    }
    
    // 수입 추가 로직
    private void handleAddIncome() {
    	String amountStr = tfIncome.getText().trim();
    	if (amountStr.isEmpty()) return;

        try {
        	int amount = Integer.parseInt(amountStr);
        	data.addIncome("수입", amount); 
            
            tfIncome.setText("");
            
            // 잔액 재계산 및 다른 탭 갱신
            handleCalcRemain();
            updateCallback.run();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "유효한 수입 금액을 입력하세요.");
        }
    }

    // 수입 삭제 로직
    private void handleDeleteIncome() {
        int row = incomeTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "삭제할 항목을 선택하세요.");
            return;
        }

        // 삭제 확인
        int confirm = JOptionPane.showConfirmDialog(this, "선택한 수입 항목을 삭제하시겠습니까?", "삭제 확인", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            String amountFormatted = incomeModel.getValueAt(row, 0).toString();
            try {
                int amount = LedgerData.parseCurrency(amountFormatted);
                
                data.removeIncomeRow(row);
                
                updateTotalIncomeColumn(); // 테이블 갱신
                updateCallback.run(); // 다른 탭 갱신
                
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "수입 금액 오류");
            }
        }
    }
    
    // 월간 총 수입 로직
    private void updateTotalIncomeColumn() {
        int currentTotal = 0;
        // 테이블을 순회하며 수입 계산
        for (int i = 0; i < incomeModel.getRowCount(); i++) {
            try {
                // 형식화된 수입 금액을 파싱
                int income = LedgerData.parseCurrency(incomeModel.getValueAt(i, 0).toString());
                currentTotal += income;
                // 월간 총 수입 컬럼에 형식화하여 저장
                incomeModel.setValueAt(LedgerData.formatCurrency(currentTotal), i, 1);
            } catch (NumberFormatException e) {	}
        }
        data.setTotalIncome(currentTotal);
    }

    // 현재 잔액 계산 및 과소비 경고 
    private void handleCalcRemain() {
    	updateRemainDisplay(); // 잔액 표시 업데이트
    }
    
    // 잔액 표시만 업데이트하는 메서드
    public void updateRemainDisplay() {
    	int totalIncome = data.getTotalIncome();
        int totalExpense = data.getTotalExpense();
        int remain = totalIncome - totalExpense; // 잔액 계산
        
        // 남은 금액을 형식화하여 표시
        if (tfRemain != null) {
            tfRemain.setText(LedgerData.formatCurrency(remain));
        }
    }
    
    // 과소비 경고 메서드
    public void checkOverspendingAlert() {
        int totalIncome = data.getTotalIncome();
        int totalExpense = data.getTotalExpense();
        
        // 과소비 여부 체크 
        if (totalIncome > 0) {
            double ratio = (double) totalExpense / totalIncome * 100;
            if (ratio > data.getOverRatio()) {
                // 이 클래스(SettingsTabPanel)를 부모 컴포넌트로 사용하여 메시지 표시
                JOptionPane.showMessageDialog(this, "주의! 과소비 판단 비율 " + data.getOverRatio() + "% 초과 (현재 " + String.format("%.2f", ratio) + "% 지출입니다).");
            }
        }
    }
    
    // 수입 테이블 ui 갱신
    public void updateIncomeTable() {
        // 수입 테이블 UI를 다시 그립니다.
        if (incomeTable != null) {
            incomeTable.revalidate();
            incomeTable.repaint();
        }
    }

    // 창 크기 변경 로직
    private void handleChangeSize() {
        String sizeStr = (String) cbSize.getSelectedItem();
        if (sizeStr == null) return;
        
        try {
            String[] parts = sizeStr.split(" x ");
            int width = Integer.parseInt(parts[0]);
            int height = Integer.parseInt(parts[1]);
            
            JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
            if (frame != null) {
                frame.setSize(width, height);
                frame.setLocationRelativeTo(null);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "창 크기 변경에 실패했습니다.");
        }
    }
}
