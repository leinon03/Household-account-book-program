package javaTeam3;

import javax.swing.table.DefaultTableModel;
import java.text.NumberFormat;
import java.time.LocalDate; 
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Comparator; 

// 모든 탭(목록, 분석, 검색, 설정)에서 공유하는 데이터 관리 클래스
// DB와 연결하여 데이터를 가져오고 모델을 업데이트 하는 클래스
public class LedgerData {

	// 테이블에 데이터를 보여주기 위한 모델
    private final DefaultTableModel expenseModel;	// 지출용
    private final DefaultTableModel incomeModel;	// 수입용

    // 실제 데이터 리스트
    private List<DBdata> expenseList = new ArrayList<>(); 	// 지출 리스트
    private List<DBdata> incomeList = new ArrayList<>();	// 수입 리스트
    
    private List<Object[]> allExpenses = new ArrayList<>();	// 분석, 검색용 데이터
    
    private final LedgerDB ledgerDB = new LedgerDB();	// DB 연결
    
    private String currentUserId;	// 현재 로그인한 사용자
    private int totalIncome = 0;	// 총 수입 합계
    private double overRatio = 50.0;	// 과소비 기준 비율 (기본 50%)
    
    // 카테고리 목록
    private final List<String> allCategories = new ArrayList<>(Arrays.asList("식비", "교통", "주거", "문화생활", "쇼핑", "여행"));

    // 로그인 성공 시 호출할 데이터
    public LedgerData(String userId) {
    	this.currentUserId = userId;    
    	
    	// 지출 테이블 목록
    	String[] expenseCols = {"날짜", "분류", "세부 카테고리", "소비 명", "지출 금액", "잔액"};
    	
    	// 셀 수정 방지 기능
        expenseModel = new DefaultTableModel(expenseCols, 0) {
        	@Override
            public boolean isCellEditable(int row, int column) {
                return false; // 셀 수정 불가(수정 버튼만 이용 가능)
            }
        };
        
        // 수입 테이블 목록
        String[] incomeCols = {"수입", "총 수입"};
        incomeModel = new DefaultTableModel(incomeCols, 0) {
        	@Override
            public boolean isCellEditable(int row, int column) {
                return false; 
            }
        };

        loadDataFromDB();	// 최신 데이터 불러오기
    }
    
    
    // Getter, Setter (외부 데이터 접근용)
    public DefaultTableModel getIncomeModel() { return incomeModel; }
    public DefaultTableModel getExpenseModel() { return expenseModel; }
    public List<Object[]> getAllExpenses() { return allExpenses; }
    public List<String> getAllCategories() { return allCategories; }
    
    public int getTotalIncome() { return totalIncome; }
    public void setTotalIncome(int income) { this.totalIncome = income; }
    public double getOverRatio() { return overRatio; }
    public void setOverRatio(double ratio) { this.overRatio = ratio; }
    
    // DB에서 데이터 불러와서 화면 갱신
    public void loadDataFromDB() {
    	// 기존 데이터 초기화
    	expenseList.clear();
        incomeList.clear();
        allExpenses.clear();
        
        // DB에서 해당 유저의 기록 가져오기
        List<DBdata> fullList = ledgerDB.getLedgerData(currentUserId);
        
        // 화면 초기화
        if (expenseModel != null) 
        	expenseModel.setRowCount(0);
        if (incomeModel != null) 
        	incomeModel.setRowCount(0);
        
        // 수입 처리 로직
        int calculatedTotalIncome = 0;
        int runningTotalIncome = 0;			// 총 수입 계산용
        
        for (DBdata d : fullList) {
            if ("수입".equals(d.getType())) {
            	calculatedTotalIncome += d.getAmount();
            	runningTotalIncome += d.getAmount();
                
            	incomeList.add(d); // 수입 리스트에 저장
                
                // 수입, 총 수입 형태로 표시
                incomeModel.addRow(new Object[] {
                    formatCurrency(d.getAmount()),   // 수입 (금액)
                    formatCurrency(runningTotalIncome) // 총 수입 (누적)
                });
            }
        }
        this.totalIncome = calculatedTotalIncome; // 전체 총 수입
        
        // 지출 처리 로직
        int cumulativeExpense = 0; // 누적 지출액
        
        // 필수/선택 지출 내역 처리
        for (DBdata d : fullList) {
            if ("필수".equals(d.getType()) || "선택".equals(d.getType())) {
            	expenseList.add(d); 
                cumulativeExpense += d.getAmount(); 
                
                // 잔액 계산
                int currentBalance = this.totalIncome - cumulativeExpense;
                
                // 화면 표시용 데이터 배열
                Object[] rowData = {
                    d.getDate(),      
                    d.getType(),      // 분류
                    d.getCategory(),  // 세부 카테고리
                    d.getTitle(),     // 소비 명
                    d.getAmount(),    // 금액
                    currentBalance    // 잔액
                };
                
                expenseModel.addRow(rowData);	// 모델에 데이터 추가
                allExpenses.add(rowData);		// 분석/검색용 리스트에 추가
            }
        }
    }
    
    // 수입 추가
    public void addIncome(String title, int amount) {
    	// 현재 날짜로 수입 데이터 생성
        DBdata data = new DBdata(currentUserId, LocalDate.now().toString(), "수입", "수입", title, amount);
        // DB저장 성공 시 화면 갱신
        if (ledgerDB.saveLedgerData(data)) 
        	loadDataFromDB();
    }
    
    // 지출 추가
    public void addExpenseRow(Object[] rowData) {
    	DBdata data = new DBdata(
                currentUserId,
                (String) rowData[0], // 날짜
                (String) rowData[1], // 분류
                (String) rowData[2], // 세부 카테고리
                (String) rowData[3], // 내용
                Integer.parseInt((String) rowData[4])	// 금액
        );
    	
    	if (ledgerDB.saveLedgerData(data)) {
            loadDataFromDB();
        }
    }
    
    // 지출 수정
    public void updateExpenseRow(int rowIndex, Object[] newData) {
    	if (rowIndex >= 0 && rowIndex < allExpenses.size()) {
    		// 수정할 데이터의 ID 가져오기
    		DBdata originalData = expenseList.get(rowIndex);
            int id = originalData.getId();
            
            // 수정용 객체 생성
            DBdata updateData = new DBdata(
                    id,
                    currentUserId,
                    (String) newData[0],
                    (String) newData[1],
                    (String) newData[2],
                    (String) newData[3],
                    Integer.parseInt((String) newData[4])
            );

            // DB 업데이트
            if (ledgerDB.updateLedgerData(updateData)) {
                loadDataFromDB(); 
            }
    	}
    }
    
    // 데이터 삭제 기능 (선택된 행 번호로 DB의 ID를 찾아서 삭제)
    public void removeExpenseRow(int rowIndex) {
        if (rowIndex >= 0 && rowIndex < expenseList.size()) {
            int id = expenseList.get(rowIndex).getId(); 
            if (ledgerDB.deleteLedgerData(id)) loadDataFromDB();
        }
    }
    
    public void removeIncomeRow(int rowIndex) {
        if (rowIndex >= 0 && rowIndex < incomeList.size()) {
            int id = incomeList.get(rowIndex).getId();
            if (ledgerDB.deleteLedgerData(id)) {
            	loadDataFromDB();
            }
        }
    }

    // 총 지출액 계산
    public int getTotalExpense() {
        int total = 0;
        for (Object[] row : allExpenses) {
            try {
                total += (Integer) row[4];
            } catch (Exception ignore) {  }
        }
        return total;
    }
    
    // 현재 잔액 반환
    public int getBalance() {
    	return getTotalIncome() - getTotalExpense(); 
    }
    
    // ------- 유틸리티 메서드 ------

    // 한국 통화 형식으로 포맷
    public static String formatCurrency(int amount) {
        return NumberFormat.getNumberInstance(Locale.KOREA).format(amount);
    }
    
    // 카테고리 관리 (추가)
    public boolean addCategory(String categoryName) {
        if (!allCategories.contains(categoryName)) {
            allCategories.add(categoryName);
            return true;
        }
        return false;
    }
    
    // 카테고리 관리 (삭제)
    public boolean removeCategory(String categoryName) {
        return allCategories.remove(categoryName);
    }
    
    // 지출 내역을 DB에 추가 후 갱신
    public void addExpense(String date, String type, String category, String title, int amount) {
    	DBdata newData = new DBdata(currentUserId, date, type, category, title, amount);
        if (ledgerDB.saveLedgerData(newData)) {
            loadDataFromDB();
        }
    }
 
    // 화폐 단위를 정수로 변환하는 메서드
    public static int parseCurrency(String currency) {
        try {
            return NumberFormat.getNumberInstance(Locale.KOREA).parse(currency).intValue();
        } catch (Exception e) {
            return 0;
        }
    }
    
    // 지출 내역을 날짜 순서대로 정렬
    private void sortExpensesByDate() {
    	// 지출 리스트 정렬
        allExpenses.sort((row1, row2) -> {
            try {
                // row[0]은 날짜 문자열 (예: "2025/11/27")
                String dateStr1 = row1[0].toString();
                String dateStr2 = row2[0].toString();

                // 문자열을 Y/M/D 형식으로 파싱
                String[] parts1 = dateStr1.split("/");
                String[] parts2 = dateStr2.split("/");

                // LocalDate로 변환하여 정확한 날짜 비교
                LocalDate date1 = LocalDate.of
                		(Integer.parseInt(parts1[0]), 
                		Integer.parseInt(parts1[1]), 
                		Integer.parseInt(parts1[2]));
                
                LocalDate date2 = LocalDate.of
                		(Integer.parseInt(parts2[0]), 
                		Integer.parseInt(parts2[1]), 
                		Integer.parseInt(parts2[2]));

                // 날짜 오름차순 정렬 (오래된 날짜가 위로)
                return date1.compareTo(date2); 
            } catch (Exception e) {
                return 0; 
            }
        });
    }
    
    // 정렬된 데이터를 바탕으로 UI에 업데이트
    private void updateExpenseModelAndTotals() {
        // 기존 테이블 삭제
    	expenseModel.setRowCount(0);
    	
    	// 잔액 계산 변수
        int currentTotal = totalIncome;
        
        // 정렬된 데이터 처리
        for (Object[] row : allExpenses) {
            try {
                int amount = (Integer) row[4];
                currentTotal += amount;
                
                Object[] displayRow = new Object[6];
                
                // 기존 데이터(날짜, 분류, 카테고리, 소비 명)
                System.arraycopy(row, 0, displayRow, 0, 4);
                
                displayRow[4] = formatCurrency(amount);    // 지출 금액
                displayRow[5] = formatCurrency(currentTotal); // 누적 합계
                
                expenseModel.addRow(displayRow);
                
            } catch (Exception ignore) {  }
        }
    }

}