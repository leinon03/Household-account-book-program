package javaTeam3;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.geom.Arc2D;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

// 분석탭
public class AnalysisTabPanel extends JSplitPane {

    private final LedgerData data;		// 가계부 데이터 관리
    
    private JLabel lblExpenseRatio;		// 총수입 대비 지출 비율 텍스트 라벨
    private JLabel lblSurplusValue;    	// 과소비 판단 결과 및 잉여금 비중 텍스트 라벨
    private JLabel lblMaxCategoryValue; // 최대 지출 항목 정보 표시 라벨 
    
    // 원형 차트 필드
    private PieChartPanel ratioChart;	// 지출/잉여금 비율 차트
    private PieChartPanel categoryChart;// 카테고리별 지출 비율 차트

    private JTable table;				// 지출 내역 목록

    // --- AnalysisTabPanel 생성자 및 메서드 ---
    public AnalysisTabPanel(LedgerData data) {
        super(JSplitPane.HORIZONTAL_SPLIT);	// 좌우 분할
        this.data = data;
        setResizeWeight(0.4); //왼쪽 40%, 오른쪽 60% 비율 설정

        // 왼쪽 UI
        JPanel left = new JPanel(new BorderLayout());
        left.setBorder(new TitledBorder("가계부 분석"));

        // 중앙 정렬 및 배치 관리를 위한 패널
        JPanel center = new JPanel();
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));

        // 제목 라벨 (필드 초기화)
        lblExpenseRatio = new JLabel("지출 비율 및 잉여 자금"); 
        JLabel lblMaxCategory  = new JLabel("항목 별 소비 비중");
        lblExpenseRatio.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblMaxCategory.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // 분석 결과 텍스트 라벨 초기화 및 중앙 정렬
        lblSurplusValue = new JLabel("총 수입 대비 지출/잉여금 비중"); 
        lblSurplusValue.setHorizontalAlignment(SwingConstants.CENTER); 
        
        lblMaxCategoryValue = new JLabel("최대 지출 항목: 없음");
        lblSurplusValue.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblMaxCategoryValue.setAlignmentX(Component.CENTER_ALIGNMENT);

        center.add(Box.createVerticalStrut(10));

        /* ----- 지출 비율/잉여금 ----- */
        center.add(lblExpenseRatio); 	  // 총수입 금액 표시
        center.add(lblSurplusValue);      // 과소비 판단 결과 표시
        center.add(Box.createVerticalStrut(5));
        
        ratioChart = new PieChartPanel(); // 원형 차트 생성
        center.add(ratioChart);
        
        /* ----- 소비 비중 최대 항목 ----- */
        center.add(Box.createVerticalStrut(20));	// 여백
        center.add(lblMaxCategory);					// 항목 별 소비 비중 제목
        center.add(lblMaxCategoryValue);  			// 지출 항목 텍스트
        center.add(Box.createVerticalStrut(5));
        
        categoryChart = new PieChartPanel();	// 카테고리별 지출 비율 원형 차트
        center.add(categoryChart);
        
        center.add(Box.createVerticalGlue());	// 하단 공간 채우기 용

        left.add(center, BorderLayout.CENTER);	// 분석 결과를 중앙에 배치

        // 오른쪽 UI
        table = new JTable(data.getExpenseModel());
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(new TitledBorder("목록"));

        setLeftComponent(left);
        setRightComponent(scroll);
        
        updateAnalysis(); // 차트 업데이트
    }
    
    // --- 차트 데이터를 담는 내부 클래스 ---
    private static class ChartData {
        String name;	// 항목 이름
        int value;		// 금액
        Color color;	// 색상
        
        ChartData(String name, int value, Color color) {
            this.name = name;
            this.value = value;
            this.color = color;
        }
    }
    
    // --- 커스텀 원형 차트 패널 ---
    private static class PieChartPanel extends JPanel {
        private List<ChartData> dataList = new ArrayList<>(); // 차트에 사용될 데이터 리스트
        
        // 차트 기본 색상 팔레트
        private static final List<Color> COLORS = Arrays.asList(
            new Color(255, 99, 132), new Color(54, 162, 235), new Color(255, 206, 86),
            new Color(75, 192, 192), new Color(153, 102, 255), new Color(255, 159, 64),
            new Color(199, 199, 199), new Color(83, 109, 254), new Color(20, 204, 96),
            new Color(255, 0, 0), new Color(0, 255, 0), new Color(0, 0, 255) 
        );

        public PieChartPanel() {
            setPreferredSize(new Dimension(300, 200));
            setBackground(Color.WHITE);
        }

        // 외부에서 데이터 받아와 차트 그리는 메서드
        public void setData(List<ChartData> data) {
            this.dataList = data;
            repaint(); 
        }

        // 실제로 그림을 그리는 메서드
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            
            // 고품질 그래픽을 위한 캐스팅
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // 차트 크기 및 위치 계산
            int width = getWidth();
            int height = getHeight();
            int legendWidth = 100; 
            int margin = 20; 
            
            // 차트 지름 계산
            int chartDiameter = Math.min(width - legendWidth - margin*2, height - margin*2); 
            int chartX = margin; 
            int chartY = margin;
            
            // 데이터 총합 계산
            int total = dataList.stream().mapToInt(d -> d.value).sum();
            
            // 데이터가 없으면 데이터 없음 표시
            if (dataList.isEmpty() || total == 0) {
                g2d.setColor(Color.LIGHT_GRAY);
                g2d.drawOval(chartX, chartY, chartDiameter, chartDiameter);
                g2d.setColor(Color.BLACK);
                g2d.drawString("데이터 없음", chartX + chartDiameter / 2 - 30, chartY + chartDiameter / 2);
                g2d.dispose();
                return;
            }

            double currentAngle = 90; 
            int colorIndex = 0;
            g2d.setFont(new Font("맑은 고딕", Font.PLAIN, 10)); 
            FontMetrics fm = g2d.getFontMetrics();

            // 파이 조각 그리기
            for (ChartData data : dataList) {
                double ratio = (double) data.value / total;
                double angle = ratio * 360;
                
                Color color = data.color != null ? data.color : COLORS.get(colorIndex % COLORS.size());
                g2d.setColor(color);
                
                Arc2D.Double arc = new Arc2D.Double(chartX, chartY, chartDiameter, chartDiameter, currentAngle, -angle, Arc2D.PIE);
                g2d.fill(arc);
                g2d.setColor(Color.BLACK);
                g2d.draw(arc); 
                
                currentAngle -= angle;
                colorIndex++;
            }
            
            // 라벨 및 범례 그리기
            currentAngle = 90; 
            colorIndex = 0;

            for (ChartData data : dataList) {
                double ratio = (double) data.value / total;
                double angle = ratio * 360;
                
                double midAngle = currentAngle - angle / 2;
                double radians = Math.toRadians(midAngle);
                
                int labelRadius = chartDiameter / 2 + 10; 
                int centerX = chartX + chartDiameter / 2;
                int centerY = chartY + chartDiameter / 2;

                int labelX = (int) (centerX + labelRadius * Math.cos(radians));
                int labelY = (int) (centerY - labelRadius * Math.sin(radians));
                
                String percentLabel = String.format("%.1f%%", ratio * 100);
                int textWidth = fm.stringWidth(percentLabel);
                
                // 텍스트 위치 보정
                if (labelX > centerX) { 
                    labelX -= textWidth; 
                } else { 
                    labelX += textWidth / 2; 
                }
                
                // 지출 비율(%)을 차트 내부에 표시
                g2d.setColor(Color.BLACK);
                g2d.drawString(percentLabel, labelX - textWidth / 2, labelY + fm.getAscent() / 2);

                currentAngle -= angle;
                
                // 3. 범례 그리기 (가격 정보 포함)
                Color color = data.color != null ? data.color : COLORS.get(colorIndex % COLORS.size());
                int legendX = chartX + chartDiameter + 10; 
                int legendY = chartY + 10 + colorIndex * 18;
                
                g2d.setColor(color);
                g2d.fillRect(legendX, legendY, 10, 10); 
                
                g2d.setColor(Color.BLACK);
                // 범례에 항목명과 가격을 표시
                String legendText = String.format("%s (%s원)", data.name, LedgerData.formatCurrency(data.value)); 
                g2d.drawString(legendText, legendX + 15, legendY + 9); 

                colorIndex++;
            }
            g2d.dispose();
        }
    }
    
    
    
    // 최신 데이터를 가져와 ui 갱신 메서드
    public void updateAnalysis() {
        
    	// 기본 통계 데이터 가져오기
        int totalIncome = data.getTotalIncome();
        int totalExpense = data.getTotalExpense();
        int surplus = totalIncome - totalExpense;	// 잉여금 = 수입 - 지출
        double overRatio = data.getOverRatio(); 	// 사용자 과소비 기준 비율
        
        // 지출 비율 및 잉여 자금 차트 갱신
        double expenseRatio = 0.0;
        
        if (totalIncome > 0) {
            expenseRatio = (double) totalExpense / totalIncome * 100;
            
            // 차트 제목 갱신 (총수입 금액 업데이트)
            lblExpenseRatio.setText(String.format("지출 비율 및 잉여 자금 (총 수입 %s원)", 
                LedgerData.formatCurrency(totalIncome)));
        } else {
            lblExpenseRatio.setText("지출 비율 및 잉여 자금");
        }

        // 첫 번째 차트용 데이터 리스트
        List<ChartData> ratioData = new ArrayList<>();
        
        // 지출 데이터 추가
        if (totalExpense > 0) {
            ratioData.add(new ChartData("지출", totalExpense, PieChartPanel.COLORS.get(0))); 
        }
        // 잉여금 데이터 추가
        if (surplus > 0 && totalIncome > 0) { 
            ratioData.add(new ChartData("잉여금", surplus, PieChartPanel.COLORS.get(1))); 
        }
        // 데이터가 없을 경우
        if (ratioData.isEmpty()) {
             ratioData.add(new ChartData("데이터 없음", 1, Color.LIGHT_GRAY));
        }

        ratioChart.setData(ratioData);
        
        // 과소비 판단 로직
        String statusLine;

        if (totalIncome > 0) {
            if (expenseRatio > overRatio) {
                // 설정된 비율을 초과한 경우
                statusLine = String.format("❌ 과소비 위험 (기준 %.1f%% 현재 %.2f%% 지출)", 
                    overRatio, expenseRatio);
                lblSurplusValue.setForeground(Color.RED); 
            } else {
                // 설정된 비율 이하인 경우
                statusLine = String.format("✅ 적정 지출 수준 (기준 %.1f%% 현재 %.2f%% 지출)", 
                    overRatio, expenseRatio);
                lblSurplusValue.setForeground(new Color(0, 150, 0)); 
            }
            
            lblSurplusValue.setText(statusLine); 

        } else {
            // 수입이 0이거나 없는 경우
            lblSurplusValue.setText("총 수입 0원 수입을 설정 탭에서 입력하세요");
            lblSurplusValue.setForeground(Color.BLACK);
        }

        // 항목별 소비 비중 차트 갱신
        Map<String, Integer> categoryExpenseMap = new HashMap<>();
        
        // 카테고리별 합계 계산
        for (Object[] expense : data.getAllExpenses()) {
            try {
                int amount = (Integer) expense[4];
                String subCategory = expense[2].toString();
                
                // 기존 값에 현재 금액 더하기
                categoryExpenseMap.put(subCategory, categoryExpenseMap.getOrDefault(subCategory, 0) + amount);
            } catch (Exception e) {	}
        }
        
        // 데이터를 리스트로 변환
        List<ChartData> categoryData = new ArrayList<>();
        String maxCategoryName = "없음";
        int maxExpense = 0;
        
        List<Map.Entry<String, Integer>> sortedCategories = categoryExpenseMap.entrySet().stream()
            .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
            .collect(Collectors.toList());

        // 정렬된 데이터를 차트 데이터로 변환
        for (Map.Entry<String, Integer> entry : sortedCategories) {
            
        	// 최대 지출 항목 찾기
            if (entry.getValue() > maxExpense) {
                maxExpense = entry.getValue();
                maxCategoryName = entry.getKey();
            }
            
            categoryData.add(new ChartData(entry.getKey(), entry.getValue(), null));
        }

        categoryChart.setData(categoryData);

        // 지출 항목 업데이트
        lblMaxCategoryValue.setText(String.format("최대 지출 항목: %s (%s원)", maxCategoryName, LedgerData.formatCurrency(maxExpense)));
    }
}