package javaTeam3;

import java.sql.*;
import java.util.ArrayList;
import java.util.*;

// 가계부 DB용
public class LedgerDB {
	// DB 연동
    private static final String URL = "jdbc:mysql://localhost:3306/udb?serverTimezone=UTC";
    private static final String ID = "root";
    private static final String PW = "cs5858325cs!";
    
    // 데이터 저장
    public boolean saveLedgerData(DBdata data) {
    	// SQL 쿼리 준비 (값이 들어갈 자리는 '?'로 비워둠)
        // client_id, date, type, category, title, amount 컬럼에 값 입력
        String sql = "INSERT INTO maindb (client_id, date, type, category, title, amount) VALUES (?, ?, ?, ?, ?, ?)";
        
        // 자원 해제
        try (Connection conn = DriverManager.getConnection(URL, ID, PW);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
        	// ?자리에 데이터 삽입
            pstmt.setString(1, data.getClientId());	// 사용자id
            pstmt.setString(2, data.getDate());		// 날짜
            pstmt.setString(3, data.getType());		// 분류
            pstmt.setString(4, data.getCategory()); // 카테고리
            pstmt.setString(5, data.getTitle());	// 소비 명
            pstmt.setInt(6, data.getAmount());		// 금액
            
            return pstmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // 데이터 삭제
    public boolean deleteLedgerData(int id) {
    	// id를 기준으로 삭제
        String sql = "DELETE FROM maindb WHERE id = ?";
        
        try (Connection conn = DriverManager.getConnection(URL, ID, PW);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {     
            
        	pstmt.setInt(1, id);	// 삭제할 id 설정
        	
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // 사용자의 가계부 데이터를 가져오는 메서드
    public ArrayList<DBdata> getLedgerData(String userId) {
        ArrayList<DBdata> list = new ArrayList<>();
        // 해당 사용자(client_id)의 데이터를 날짜순으로 조회
        String sql = "SELECT * FROM maindb WHERE client_id = ? ORDER BY date ASC";

        try (Connection conn = DriverManager.getConnection(URL, ID, PW);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
             
            pstmt.setString(1, userId);
            
            // 조회 결과 받아오기
            ResultSet rs = pstmt.executeQuery();

            // 리스트에 추가
            while (rs.next()) {
                list.add(new DBdata(
                    rs.getInt("id"),			// 고유번호
                    rs.getString("client_id"),	// 사용자 ID
                    rs.getString("date"),		// 날짜
                    rs.getString("type"),		// 분류
                    rs.getString("category"),	// 카테고리
                    rs.getString("title"),		// 소비 명
                    rs.getInt("amount")			// 금액
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;	// 완성된 리스트 반환
    }
    
    // 기존 데이터 수정하는 메서드
    public boolean updateLedgerData(DBdata data) {
    	// 특정 id의 데이터를 찾아 새로운 값으로 덮어씌우기
    	String sql = "UPDATE maindb SET date=?, type=?, category=?, title=?, amount=? WHERE id=?";
        
    	try (Connection conn = DriverManager.getConnection(URL, ID, PW);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
    		// 수정할 값 삽입
            pstmt.setString(1, data.getDate());
            pstmt.setString(2, data.getType());
            pstmt.setString(3, data.getCategory());
            pstmt.setString(4, data.getTitle());
            pstmt.setInt(5, data.getAmount());
            pstmt.setInt(6, data.getId()); // 수정할 대상의 PK(ID)
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
