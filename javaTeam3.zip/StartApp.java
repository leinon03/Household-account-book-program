package javaTeam3;

import javax.swing.*;

// 프로그램 실행
public class StartApp {
	public static void main(String[] args) {
		// GUI 갱신하는 작업의 안전을 보장하기 위해
		SwingUtilities.invokeLater(() -> {
            Login loginPage = new Login();
            loginPage.login();
        });
	}

}
