package javaTeam3;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

// 검색
public class SearchTabPanel extends JSplitPane {

    private final LedgerData data;
    
    // 검색 결과를 보여주는 테이블
    private final DefaultTableModel searchResultModel;
    
    // 날짜 검색용(시작일 ~ 종료일)
    private JComboBox<String> cbDateFrom;
    private JComboBox<String> cbDateTo;
    
    // 카테고리 검색용
    private JComboBox<String> cbCategorySearch;
   
    // 소비 명 검색용
    private JTextField tfTitleSearch;
    
    // 금액 검색용
    private JTextField tfAmountSearch;
    private JRadioButton rbAmountGte, rbAmountLte, rbAmountEq;

    // UI 요소 필드 추가
    private JComboBox<String> type; 
    private CardLayout card;
    private JPanel cardPanel;
    private JButton btnSearch;
    private JButton btnReset;

    // 검색창 UI
    public SearchTabPanel(LedgerData data) {
        super(JSplitPane.HORIZONTAL_SPLIT);
        this.data = data;

        // 결과 테이블
        String[] expenseCols = {"날짜", "분류", "세부 카테고리", "소비 명", "지출 금액", "합계"};
        
        // 셀 수정 방지
        searchResultModel = new DefaultTableModel(expenseCols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
            	return false;
            }
        };

        setResizeWeight(0.3);

        // 검색 조건 패널 구성
        JPanel left = new JPanel(new GridBagLayout());
        left.setBorder(new TitledBorder("검색"));

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5,5,5,5);
        c.gridx=0;
        c.weightx=1;
        c.fill = GridBagConstraints.HORIZONTAL;

        // 상단 검색 기준 콤보 박스
        JPanel top = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 5));
        top.add(new JLabel("검색 기준: "));

        type = new JComboBox<>(new String[]{"날짜","카테고리","소비명","지출액"}); 
        type.setPreferredSize(new Dimension(110, 25));
        top.add(type);

        c.gridy=0;
        left.add(top,c);

        // 카드 영역
        card = new CardLayout(); 
        cardPanel = new JPanel(card); 

        // 콤보박스 전환 이벤트
        cardPanel.add(datePanel(), "DATE");
        cardPanel.add(categoryPanel(), "CATEGORY");
        cardPanel.add(titlePanel(), "TITLE");
        cardPanel.add(amountPanel(), "AMOUNT");

        c.gridy=1;
        left.add(cardPanel,c);
        
        // 검색/초기화 버튼 
        btnSearch = new JButton("검색");
        btnReset = new JButton("초기화");

        // 검색 결과 테이블 구성
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        buttonPanel.add(btnSearch); buttonPanel.add(btnReset);
        
        c.gridy=2; c.gridwidth=2; 
        left.add(buttonPanel, c);

        type.addActionListener(e -> {
            switch (type.getSelectedIndex()) {
                case 0 -> card.show(cardPanel,"DATE");
                case 1 -> card.show(cardPanel,"CATEGORY");
                case 2 -> card.show(cardPanel,"TITLE");
                case 3 -> card.show(cardPanel,"AMOUNT");
            }
        });
        
        bindCommonEvents();

        JTable table = new JTable(searchResultModel);
        table.setFillsViewportHeight(true);
        JScrollPane right = new JScrollPane(table);
        right.setBorder(new TitledBorder("목록"));

        updateDateComboBox(); // 날짜 콤보박스 초기화
        updateSearchResultTable(data.getAllExpenses());

        setLeftComponent(left);
        setRightComponent(right);
    }
    
    // 검색 조건 설정
    private void bindCommonEvents() {
        btnSearch.addActionListener(e -> {
            String selectedType = (String) type.getSelectedItem();
            if (selectedType != null) {
                switch (selectedType) {
                    case "날짜": searchByDate(); break;
                    case "카테고리": searchByCategory(); break;
                    case "소비명": searchByTitle(); break;
                    case "지출액": searchByAmount(); break;
                }
            }
        });
        btnReset.addActionListener(e -> onResetSearch());
    }
    
    // 검색 결과를 테이블에 반영
    public void updateSearchResultTable(List<Object[]> results) { 
        searchResultModel.setRowCount(0);
        
        int currentTotal = 0;	// 누적 합계 계산용
        
        // 리스트를 순회하며 테이블에 행 추가
        for (Object[] row : results) {
            try {
                int amount = (Integer) row[4];
                currentTotal += amount;
                
                Object[] displayRow = new Object[6];
                System.arraycopy(row, 0, displayRow, 0, 4); // 날짜, 분류, 세부 카테고리, 소비 명 (0~3)
                displayRow[4] = LedgerData.formatCurrency(amount); // 지출 금액 (4) - 형식화
                displayRow[5] = LedgerData.formatCurrency(currentTotal); // 누적 합계 (5) - 형식화
                
                searchResultModel.addRow(displayRow);    
            } catch (Exception ignore) {  }
        }
    }
    
    // 검색 조건 초기화 및 전체 목록 재표시
    private void onResetSearch() {
        resetInputFields(); 
        updateSearchResultTable(data.getAllExpenses());
    }

    // 검색 필드 초기화
    private void resetInputFields() {
        // 날짜 필드 초기화 (콤보박스의 첫 번째와 마지막 날짜로)
        updateDateComboBox(); // 날짜 목록을 다시 채우고 자동 선택되도록 함

        // 기타 필드 초기화
        // 카테고리 전체 선택
        if (cbCategorySearch != null && cbCategorySearch.getItemCount() > 0) cbCategorySearch.setSelectedIndex(0);
        if (tfTitleSearch != null) tfTitleSearch.setText("");	// 소비 명 초기화
        if (tfAmountSearch != null) tfAmountSearch.setText(""); // 금액 초기화
        if (rbAmountEq != null) rbAmountEq.setSelected(true); 	// 금액 비교 조건 현재값 선책
    }


    /* ---------------- 날짜 검색 UI ---------------- */
    private JPanel datePanel() {
        JPanel p = new JPanel(new GridBagLayout());
        GridBagConstraints c = baseConstraints();
        
        // JComboBox 생성 (생성자에서 초기화)
        cbDateFrom = new JComboBox<>();
        cbDateTo = new JComboBox<>();
        
        // 시작 날짜
        c.gridx=0; c.gridy=0; c.weightx=0; c.gridwidth=1;
        p.add(new JLabel("시작일"), c); 
        c.gridx=1; c.weightx=1.0;
        p.add(cbDateFrom, c);

        // 종료 날짜
        c.gridx=0; c.gridy=1; c.weightx=0;
        p.add(new JLabel("끝일"), c); 
        c.gridx=1; c.weightx=1.0;
        p.add(cbDateTo, c);

        return p;
    }
    
    // 콤보박스 갱신
    public void updateDateComboBox() {
        Set<String> dateSet = new HashSet<>();	// 날짜 중복 제거
        
    	cbDateFrom.removeAllItems();
        cbDateTo.removeAllItems();
        
        List<Object[]> allData = data.getAllExpenses();
 
        // 모든 데이터에서 날짜만 추출하여 중복 제거 (Set 사용)
        for (Object[] row : allData) {
            dateSet.add((String) row[0]);
        }
        
        // 날짜순으로 정렬
        List<String> sortedDates = dateSet.stream().sorted().collect(Collectors.toList());
        
        // 콤보박스에 추가
        for (String d : sortedDates) {
            cbDateFrom.addItem(d);
            cbDateTo.addItem(d);
        }
        
        // 편의상 '종료 날짜'는 가장 최근 날짜로 기본 선택
        if (!sortedDates.isEmpty()) {
            cbDateTo.setSelectedIndex(sortedDates.size() - 1);
        }
    }

    // 날짜 검색 로직: 콤보박스에서 선택된 날짜 범위로 필터링
    private void searchByDate() {
        String fromStr = (String) cbDateFrom.getSelectedItem();
        String toStr = (String) cbDateTo.getSelectedItem();
        
        if (fromStr == null || toStr == null) {
            JOptionPane.showMessageDialog(this, "데이터가 없어 검색할 수 없습니다.");
            return;
        }

        // 문자열을 날짜 객체(LocalDate)로 변환
        LocalDate fromDate = parseDate(fromStr);
        LocalDate toDate = parseDate(toStr);
        
        if (fromDate == null || toDate == null) return;

        // 날짜 순서 검사
        if (fromDate.isAfter(toDate)) {
            JOptionPane.showMessageDialog(this, "시작 날짜가 종료 날짜보다 늦을 수 없습니다.");
            return;
        }

        List<Object[]> filtered = new ArrayList<>();
        
        // 모든 데이터를 순회하며 날짜 범위 확인
        for (Object[] row : data.getAllExpenses()) {
            String rowDateStr = (String) row[0];
            LocalDate rowDate = parseDate(rowDateStr);
            
            // 범위 안에 포함되면 리스트에 추가 (!이전 && !이후 -> 포함)
            if (rowDate != null && !rowDate.isBefore(fromDate) && !rowDate.isAfter(toDate)) {
                filtered.add(row);
            }
        }
        
        // 결과 테이블 갱신
        updateSearchResultTable(filtered);
    }
    
    /* ---------------- 카테고리 콤보박스 관리 메서드 ---------------- */
    // 콤보박스에 항목 채우기
    private void populateCategoryComboBox() {
        if (cbCategorySearch == null) {
            cbCategorySearch = new JComboBox<>();
        } else {
            cbCategorySearch.removeAllItems();	// 기존 항목 제거
        }
        cbCategorySearch.addItem("전체");		// 기본값 전체 추가
        
        // 가테고리 목록을 가져와 추가
        for (String cat : data.getAllCategories()) {
            cbCategorySearch.addItem(cat);
        }
    }
    
    // 콤보박스 갱신
    public void updateCategoryComboBox() {
        if (cbCategorySearch != null) {
            populateCategoryComboBox();
        }
    }
    
    // 카테고리 검색용 ui패널
    private JPanel categoryPanel() {
        JPanel p = new JPanel(new GridBagLayout());
        GridBagConstraints c = baseConstraints();

        populateCategoryComboBox();
        
        cbCategorySearch.setPreferredSize(new Dimension(140, 25));

        c.gridx=0; c.gridy=0; c.weightx=0;
        p.add(new JLabel("세부 카테고리"), c);
        c.gridx=1; c.weightx=1.0;
        p.add(cbCategorySearch, c);

        return p;
    }
    
    // 카테고리 검색 로직
    private void searchByCategory() {
        String selectedCat = (String) cbCategorySearch.getSelectedItem();
        if (selectedCat == null) return;
        
        List<Object[]> filtered = data.getAllExpenses().stream()
            .filter(row -> selectedCat.equals("전체") || row[2].toString().equals(selectedCat)) // 2: 세부 카테고리
            .collect(Collectors.toList());
        updateSearchResultTable(filtered);
    }

    /* ---------------- 소비명 ---------------- */
    // 소비명 검색 ui 패널
    private JPanel titlePanel() {
        JPanel p = new JPanel(new GridBagLayout());
        GridBagConstraints c = baseConstraints();

        tfTitleSearch = new JTextField();
        tfTitleSearch.setPreferredSize(new Dimension(170, 25));

        c.gridx=0; c.gridy=0; c.weightx=0;
        p.add(new JLabel("소비 명"), c);
        c.gridx=1; c.weightx=1.0;
        p.add(tfTitleSearch, c);

        return p;
    }
    
    // 소비명 검색 로직
    private void searchByTitle() {
        String searchText = tfTitleSearch.getText().trim().toLowerCase();
        if (searchText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "소비 명을 입력하세요.");
            return;
        }
        
        List<Object[]> filtered = data.getAllExpenses().stream()
            .filter(row -> row[3].toString().toLowerCase().contains(searchText)) // 3: 소비 명
            .collect(Collectors.toList());
        updateSearchResultTable(filtered);
    }

    /* ---------------- 지출액 ---------------- */
    // 지출액 검색용 ui 패널
    private JPanel amountPanel() {
        JPanel p = new JPanel(new GridBagLayout());
        GridBagConstraints c = baseConstraints();

        tfAmountSearch = new JTextField();
        tfAmountSearch.setPreferredSize(new Dimension(170, 25));

        // 비교 라디오 버튼
        ButtonGroup bg = new ButtonGroup();
        rbAmountGte = new JRadioButton("이상");
        rbAmountLte = new JRadioButton("이하");
        rbAmountEq = new JRadioButton("현재값",true);
        bg.add(rbAmountGte); bg.add(rbAmountLte); bg.add(rbAmountEq);

        JPanel radioPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        radioPanel.add(rbAmountGte);
        radioPanel.add(rbAmountLte);
        radioPanel.add(rbAmountEq);

        // 비교 조건 라디오 버튼
        c.gridx=0; c.gridy=0; c.gridwidth=2;
        p.add(radioPanel, c);
        c.gridwidth=1;

        // 금액 입력 필드
        c.gridx=0; c.gridy=1; c.weightx=0;
        p.add(new JLabel("금액"), c);
        c.gridx=1; c.weightx=1.0;
        p.add(tfAmountSearch, c);

        return p;
    }
    
    // 금액 검색 로직
    private void searchByAmount() {
        String amountStr = tfAmountSearch.getText().trim();
        if (amountStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "검색할 금액을 입력하세요.");
            return;
        }
        
        try {
            int searchAmount = Integer.parseInt(amountStr);	// 검색 기준 금액
            
            List<Object[]> filtered = data.getAllExpenses().stream()
                .filter(row -> {
                    try {
                        int actualAmount = (Integer) row[4]; // 4: 지출 금액 (Integer)
                        if (rbAmountGte.isSelected()) return actualAmount >= searchAmount;
                        if (rbAmountLte.isSelected()) return actualAmount <= searchAmount;
                        if (rbAmountEq.isSelected()) return actualAmount == searchAmount;
                    } catch (Exception ignore) { return false; }
                    return false;
                })
                .collect(Collectors.toList());
            updateSearchResultTable(filtered);
            
        } catch (NumberFormatException ex) {
        	// 숫자가 아닌 값이 입력된 경우
            JOptionPane.showMessageDialog(this, "유효한 숫자를 입력하세요.");
        }
    }
    
    // ------- 유틸리티 메서드 -------
    // GridBagLayout에 사용되는 기본 제약 조건 반환
    private GridBagConstraints baseConstraints() {
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.anchor = GridBagConstraints.WEST;
        c.weightx = 1.0;
        return c;
    }
    
    // 날짜 구분자 처리
    private LocalDate parseDate(String dateStr) {
        try {
            String[] parts;
            // 하이픈(-) 또는 슬래시(/) 구분자 처리
            if (dateStr.contains("-")) {
                parts = dateStr.split("-");
            } else {
                parts = dateStr.split("/");
            }
            
            return LocalDate.of(
                Integer.parseInt(parts[0]), // 년
                Integer.parseInt(parts[1]), // 월
                Integer.parseInt(parts[2])  // 일
            );
        } catch (Exception e) {
            return null;
        }
    }
}