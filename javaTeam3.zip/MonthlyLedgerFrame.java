package javaTeam3;

import javax.swing.*;
import java.awt.*;

// 메인 화면
public class MonthlyLedgerFrame extends JFrame {

    private final LedgerData data;
    
    // 핵심 기능 패널
    private final SettingsTabPanel settingsTab; // 설정
    private final ListTabPanel listTab;			// 목록
    private final AnalysisTabPanel analysisTab;	// 분석
    private final SearchTabPanel searchTab;		// 검색
    

    // 메인화면 UI
    public MonthlyLedgerFrame(String userId) {
        super("월간 가계부");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 500); 
        setLocationRelativeTo(null); 

        // 데이터 관리
        data = new LedgerData(userId);

        // 데이터 갱신 콜백 정의
        Runnable updateCallback = this::updateAllPanels;

        // 각 탭 패널 생성
        settingsTab = new SettingsTabPanel(data, updateCallback);
        listTab = new ListTabPanel(data, updateCallback, settingsTab); 
        analysisTab = new AnalysisTabPanel(data);
        searchTab = new SearchTabPanel(data);
    

        // 탭 컨테이너 생성 및 등록
        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("목록", listTab);
        tabs.addTab("분석", analysisTab);
        tabs.addTab("검색", searchTab);
        tabs.addTab("설정", settingsTab);
        
        // 탭 전환 이벤트 리스너
        tabs.addChangeListener(e -> {
            Component selected = tabs.getSelectedComponent();
            
            // 분석 탭 눌렀을 때
            if (selected == analysisTab) {
                analysisTab.updateAnalysis();
            } 
            // 검색 탭 눌렀을 때
            else if (selected == searchTab) {
                searchTab.updateDateComboBox(); // 탭 전환 시 날짜 콤보박스 갱신 추가
                searchTab.updateSearchResultTable(data.getAllExpenses());
                searchTab.updateCategoryComboBox(); 
            }
        });

        add(tabs, BorderLayout.CENTER);
        
        updateAllPanels();
        setVisible(true);
    }
    
    // 모든 탭의 화면을 최신 데이터로 동기화하는 메서드
    public void updateAllPanels() {
    	data.loadDataFromDB(); // 데이터 로드
        listTab.updateExpenseTable();	// 목록 탭 UI 갱신
        settingsTab.updateIncomeTable();// 분석 탭 갱신
        // 검색 탭 콤보박스 선택 항목 갱신
        settingsTab.updateRemainDisplay();
        analysisTab.updateAnalysis();
    }
}