package javaTeam3;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement; // PreparedStatement 사용을 위해 추가
import java.sql.ResultSet;
import java.sql.SQLException;

// 회원관리 DB
public class UserDB {
	
    // DB 연결 정보
    private static final String URL = "jdbc:mysql://localhost:3306/udb?serverTimezone=UTC";
    private static final String ID = "root";
    private static final String PW = "cs5858325cs!";

    // DB 연결
    private Connection getConnection() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(URL, ID, PW);
    }
    
    // DB에 ID,PW 삽입
    public boolean registerUser(String userID, String userPW) {
    	String insertSQL = "INSERT INTO client (ID, password) VALUES (?, ?)";

    	try (Connection conn = getConnection()) { // Connection 객체를 여기서 선언 및 관리

            // ID 중복 체크
            if (isIDExists(userID, conn)) {
                System.out.println("ID 중복: " + userID);
                return false;
            }

            // DB에 ID와 pw를 삽입
            try (PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {
                pstmt.setString(1, userID);
                pstmt.setString(2, userPW);

                return pstmt.executeUpdate() > 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("DB 작업 오류: " + e.getMessage());
        }
        return false;
    }
    
    // ID 중복 여부만 확인하는 내부 메서드
    private boolean isIDExists(String userID, Connection conn) throws SQLException {
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        // 대소문자 구별하여 비교
        String checkSQL = "SELECT ID FROM client WHERE BINARY ID = ?";
        
        try {
            pstmt = conn.prepareStatement(checkSQL);
            pstmt.setString(1, userID);
            rs = pstmt.executeQuery();
            
            return rs.next(); // ID가 존재하면 true
        } finally {
            if (rs != null) rs.close();
            if (pstmt != null) pstmt.close();
        }
    }


    // 로그인 로직
    public boolean loginUser(String userID, String userPW) {
    	// 아이디와 비밀번호가 일치하는지 확인 (대소문자 구분)
    	String sql = "SELECT ID FROM client WHERE BINARY ID = ? AND BINARY password = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, userID);
            pstmt.setString(2, userPW);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
