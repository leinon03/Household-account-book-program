package javaTeam3;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

//회원가입
class Membership extends JFrame implements ActionListener, FocusListener{
	private JTextField idField;				// 아이디 입력
	private JTextField pwField;				// 비밀번호 입력
	private JButton newlogjb;				// 회원가입 버튼
	private JLabel exjl;					// 큰 제목(회원가입)
	
	private UserDB udb = new UserDB();
	
	// 회원가입 UI
	public void membership(){
		Container ct = getContentPane();
		setLayout(new BorderLayout());
		
		// 상단 제목
		JPanel ex = new JPanel();
		exjl = new JLabel("회원가입", SwingConstants.CENTER);
		exjl.setFont(new Font("맑은 고딕", Font.BOLD, 30));
	    exjl.setBorder(BorderFactory.createEmptyBorder(50, 0, 30, 0));
		ex.add(exjl);
		
		// 회원가입
		JPanel login = new JPanel(new GridLayout(2, 2, 5, 5));
		JLabel id = new JLabel("아이디");
		id.setFont(new Font("맑은 고딕", Font.BOLD, 15));			// 아이디 폰트
		JLabel pw = new JLabel("비밀번호");
		pw.setFont(new Font("맑은 고딕", Font.BOLD, 15));			// 비밀번호 폰트
		idField = new JTextField("2자리 이상 8자리 이하", 15);		// 아이디 텍스트필드
		pwField = new JTextField("4자리 이상 20자리 이하", 15);		// 비밀번호 텍스트필드
		
		login.add(id);
		login.add(idField);
		login.add(pw);
		login.add(pwField);
		login.setBorder(BorderFactory.createEmptyBorder(50, 180, 10, 0));
		
		// 텍스트필드 이벤트
		idField.addFocusListener(this);
		pwField.addFocusListener(this);
			
		// 회원가입 버튼
		JPanel logjp = new JPanel(new BorderLayout());
		newlogjb = new JButton("회원가입");
		newlogjb.addActionListener(this);
		logjp.add(newlogjb, BorderLayout.EAST);
		logjp.setBorder(BorderFactory.createEmptyBorder(50, 10, 10, 200));
		 
		// 아래 쪽 빈칸 만들기
		JPanel membership = new JPanel(new BorderLayout());
		membership.setBorder(BorderFactory.createEmptyBorder(0, 0, 200, 0));
		
		// 새로운 패널을 만들어 한곳에서 정리
		JPanel inlogjp = new JPanel(new BorderLayout());
		inlogjp.add(login, BorderLayout.WEST);
		inlogjp.add(logjp, BorderLayout.EAST);
		inlogjp.add(membership, BorderLayout.SOUTH);
		
		// JFrame에 모든 패널 넣기
		add(ex, BorderLayout.NORTH);		// 회원가입 글씨
		add(inlogjp, BorderLayout.CENTER);  // 회원가입 기능
		
		setTitle("월간 가계부");
		setSize(800, 500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		
	}
		
	// 회원가입 텍스트필드 설명 이벤트
	public void focusGained(FocusEvent e) {
		if (e.getSource() == idField) {
			if (idField.getText().equals("2자리 이상 8자리 이하")) {
				idField.setText("");
			}
		} else if (e.getSource() == pwField) {
			if (pwField.getText().equals("4자리 이상 20자리 이하")) {
				pwField.setText("");
			}
		}
	}
		 
	// 회원가입 텍스트필드 설명 이벤트
	public void focusLost(FocusEvent e) {
		if (e.getSource() == idField) {
			if (idField.getText().isEmpty()) {
				idField.setText("2자리 이상 8자리 이하");
			}
		} else if (e.getSource() == pwField) {
			if (pwField.getText().isEmpty()) {
				pwField.setText("4자리 이상 20자리 이하");
			}
		}
	}
		
	// 회원가입 버튼 이벤트
	public void actionPerformed(ActionEvent e) {
		Object src = e.getSource();
			 
		if (src == newlogjb) { 
			String userID = idField.getText().trim();
            String userPW = pwField.getText().trim();
				 
            if (userID.equals("2자리 이상 8자리 이하") || userID.isEmpty()) {
                JOptionPane.showMessageDialog(null, "아이디를 입력해주세요.", "회원가입 경고", JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            if (userPW.equals("4자리 이상 20자리 이하") || userPW.isEmpty()) {
                JOptionPane.showMessageDialog(null, "비밀번호를 입력해주세요.", "회원가입 경고", JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            // 아이디 길이 제한 (2 ~ 8)
            if (userID.length() < 2 || userID.length() > 8) {
                JOptionPane.showMessageDialog(null, "아이디는 2자리 이상 8자리 이하이어야 합니다.", "아이디 조건 오류", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // 비밀번호 길이 제한 (4 ~ 20)
            if (userPW.length() < 4 || userPW.length() > 20) {
                JOptionPane.showMessageDialog(null, "비밀번호는 4자리 이상 20자리 이하이어야 합니다.", "비밀번호 조건 오류", JOptionPane.WARNING_MESSAGE);
                return;
            }
            
			// DB에 사용자 등록 시도
			boolean success = udb.registerUser(userID, userPW);
	           
			if (success) {
				// 성공 시 로그인 화면으로 이동
				JOptionPane.showMessageDialog(null, "회원가입 성공", "회원가입", JOptionPane.INFORMATION_MESSAGE);

				dispose();
		        Login loginPage = new Login();
		        loginPage.login();        
			}
		} else { 
			// false인 경우 (ID 중복 또는 DB 오류)      
			JOptionPane.showMessageDialog(null, "회원가입에 실패", "회원가입 실패", JOptionPane.WARNING_MESSAGE);
			idField.setText("");
            pwField.setText("");
		}
	} 
}
