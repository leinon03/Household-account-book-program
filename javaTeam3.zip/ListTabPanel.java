package javaTeam3;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.time.LocalDate;
import java.util.ArrayList;

// 목록 탭
public class ListTabPanel extends JSplitPane {

    private final LedgerData data;				  // 데이터베이스 로직 관리
    private final DefaultTableModel expenseModel; // ui에 데이터를 연결해줄 모델
    private final Runnable updateCallback;		  // 데이터 변경 시 다른 탭을 갱신하기 위한 콜백 함수
    private final SettingsTabPanel settingsTab;   // 과소비 알림을 위한 설정 탭 참조

    // 입력 컴포넌트 
    private JRadioButton rbNeed, rbChoice;	// 분류 버튼
    private JComboBox<String> cbCategory;	// 카테고리 콤보박스
    
	// 날짜, 소비 내용, 지출 금액 입력 필드
    private JTextField tfYear, tfMonth, tfDay, tfTitle, tfAmount; 

    // 버튼
    private JButton btnAddCategory, btnDeleteCategory;	// 카테고리 버튼
    private JButton btnAddRow, btnEditRow, btnDeleteRow; // 데이터 조작 버튼

    private JTable table;	// 지출 목록 테이블

    // UI 구성
    public ListTabPanel(LedgerData data, Runnable updateCallback, SettingsTabPanel settingsTab) {
        super(JSplitPane.HORIZONTAL_SPLIT);
        this.data = data;
        this.expenseModel = data.getExpenseModel();
        this.updateCallback = updateCallback;
        this.settingsTab = settingsTab;

        setResizeWeight(0.3);

        JPanel leftPanel = buildInputPanel();

        table = new JTable(expenseModel);
        table.setFillsViewportHeight(true);
        
        // 테이블 행 선택 시 입력 필드 채우기 이벤트 바인딩
        table.getSelectionModel().addListSelectionListener(this::onRowSelected);

        JScrollPane rightScroll = new JScrollPane(table);
        rightScroll.setBorder(new TitledBorder("목록"));

        setLeftComponent(leftPanel);
        setRightComponent(rightScroll);
    }

    // 왼쪽 UI
    private JPanel buildInputPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(new TitledBorder("지출 입력"));

        GridBagConstraints c = baseConstraints();
        int y = 0;

        // 분류
        rbNeed = new JRadioButton("필수", true); // 기본 선택
        rbChoice = new JRadioButton("선택");

        ButtonGroup bg = new ButtonGroup();
        bg.add(rbNeed);
        bg.add(rbChoice);

        JPanel radioPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        radioPanel.add(rbNeed);
        radioPanel.add(rbChoice);

        addLine(panel, c, y++, "분류", radioPanel);

        // 세부 카테고리 콤보박스 및 버튼
        cbCategory = new JComboBox<>(data.getAllCategories().toArray(new String[0]));
        cbCategory.setPreferredSize(new Dimension(100, 25));

        btnAddCategory = new JButton("추가");
        btnDeleteCategory = new JButton("삭제");

        JPanel categoryPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        categoryPanel.add(cbCategory);
        categoryPanel.add(btnAddCategory);
        categoryPanel.add(btnDeleteCategory);
        
        addLine(panel, c, y++, "세부 카테고리", categoryPanel);
        
        // 날짜 입력 필드 (년 월 일 3개 필드 배치)
        LocalDate today = LocalDate.now();
        tfYear = new JTextField(String.valueOf(today.getYear()));
        tfMonth = new JTextField(String.valueOf(today.getMonthValue()));
        tfDay = new JTextField(String.valueOf(today.getDayOfMonth()));
        
        tfYear.setToolTipText("년(4자리)");
        tfMonth.setToolTipText("월");
        tfDay.setToolTipText("일");

        // GridBagLayout을 사용하여 세 개의 텍스트 필드와 '년 월 일' 라벨을 배치
        JPanel datePanel = new JPanel(new GridBagLayout());
        GridBagConstraints dc = new GridBagConstraints(); // dc: date constraints
        dc.fill = GridBagConstraints.HORIZONTAL;
        dc.insets = new Insets(0, 0, 0, 5);
        
        // 년, 월, 일 필드와 라벨을 교차 배치
        dc.gridx = 0; dc.weightx = 1.0; datePanel.add(tfYear, dc); 
        dc.gridx = 1; dc.weightx = 0; datePanel.add(new JLabel("년"), dc); 
        dc.gridx = 2; dc.weightx = 1.0; datePanel.add(tfMonth, dc); 
        dc.gridx = 3; dc.weightx = 0; datePanel.add(new JLabel("월"), dc); 
        dc.gridx = 4; dc.weightx = 1.0; datePanel.add(tfDay, dc); 
        dc.gridx = 5; dc.weightx = 0; dc.insets = new Insets(0, 0, 0, 0); 
        datePanel.add(new JLabel("일"), dc);
        
        // datePanel은 gridx=1 위치에 위치하며 weightx=1.0을 받아 소비 명 필드와 같은 너비를 가진다
        addLine(panel, c, y++, "날짜", datePanel);

        // 소비 명 입력 필드
        tfTitle = new JTextField();
        addLine(panel, c, y++, "소비 명", tfTitle);

        // 금액 입력 필드
        tfAmount = new JTextField();
        tfAmount.setToolTipText("숫자만 입력");
        addLine(panel, c, y++, "지출 금액", tfAmount);

        // 하단 조작 버튼
        btnAddRow = new JButton("추가");
        btnEditRow = new JButton("수정");
        btnDeleteRow = new JButton("삭제");

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        buttonPanel.add(btnAddRow);
        buttonPanel.add(btnEditRow);
        buttonPanel.add(btnDeleteRow);
        
        addFullWidthLine(panel, c, y++, buttonPanel);

        // 이벤트 연결
        bindEvents();

        return panel;
    }

    // 버튼 이벤트 리스너
    private void bindEvents() {
    	// 카테고리 추가
        btnAddCategory.addActionListener(e -> { 
            String newCategory = JOptionPane.showInputDialog(this, "새로운 세부 카테고리를 입력하세요.");
            if (newCategory != null && !newCategory.trim().isEmpty()) {
                if (data.addCategory(newCategory.trim())) {
                    cbCategory.addItem(newCategory.trim());	// 콤보박스에 추가
                    cbCategory.setSelectedItem(newCategory.trim());
                } else {
                    JOptionPane.showMessageDialog(this, "이미 존재하는 카테고리입니다.");
                }
            }
        });
        
        // 카테고리 삭제
        btnDeleteCategory.addActionListener(e -> { 
             String selectedCategory = (String) cbCategory.getSelectedItem();
             if (selectedCategory != null) {
                 int confirm = JOptionPane.showConfirmDialog(this, selectedCategory + " 카테고리를 삭제하시겠습니까?", "삭제 확인", JOptionPane.YES_NO_OPTION);
                 if (confirm == JOptionPane.YES_OPTION) {
                     if (data.removeCategory(selectedCategory)) {
                         cbCategory.removeItem(selectedCategory); // 콤보박스에서 제거
                     } else {
                         JOptionPane.showMessageDialog(this, "카테고리 삭제 중 오류가 발생했습니다.");
                     }
                 }
             } else {
                 JOptionPane.showMessageDialog(this, "삭제할 카테고리를 선택하세요.");
             }
        });

        // 데이터 이벤트 연결
        btnAddRow.addActionListener(this::onAddRow);
        btnEditRow.addActionListener(this::onEditRow);
        btnDeleteRow.addActionListener(this::onDeleteRow);
    }

    // ------ 레이아웃 유틸리티 메서드 ------
    private GridBagConstraints baseConstraints() {
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.anchor = GridBagConstraints.WEST;
        c.weightx = 1.0;
        return c;
    }

    private void addLine(JPanel parent, GridBagConstraints c, int y, String label, Component comp) {
        c.gridx = 0;
        c.gridy = y;
        c.weightx = 0;
        c.gridwidth = 1;
        parent.add(new JLabel(label), c);

        c.gridx = 1;
        c.weightx = 1.0;
        parent.add(comp, c);
    }

    private void addFullWidthLine(JPanel parent, GridBagConstraints c, int y, Component comp) {
        c.gridx = 0;
        c.gridy = y;
        c.gridwidth = 2;
        c.weightx = 1.0;
        parent.add(comp, c);
    }

    // ------ 이벤트 처리 메서드 -------
    
    // 셀 클릭 시 해당 데이터 입력 필드에 채우기
    private void onRowSelected(ListSelectionEvent e) {
        if (e.getValueIsAdjusting()) return; // 이벤트 중복 발생 방지
        
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            resetInputFields(); // 선택 해제 시 입력창 초기화
            return;
        }
        try {
        	// 데이터 가져오기(날짜, 분류, 카테고리, 소비 명, 금액)
        	String dateStr = expenseModel.getValueAt(selectedRow, 0).toString();
        	String categoryType = expenseModel.getValueAt(selectedRow, 1).toString();
        	String subCategory = expenseModel.getValueAt(selectedRow, 2).toString();
        	String title = expenseModel.getValueAt(selectedRow, 3).toString();
        	String amountStr = expenseModel.getValueAt(selectedRow, 4).toString(); 

        	// 날짜 분리
        	String[] dateParts = dateStr.split("/"); 
        	if (dateParts.length == 3) {
        		tfYear.setText(dateParts[0]);
        		tfMonth.setText(dateParts[1]);
        		tfDay.setText(dateParts[2]);
        	}
        
        	// 분류 라디오 버튼
        	if ("필수".equals(categoryType)) {
        		rbNeed.setSelected(true);
        	} else {
        		rbChoice.setSelected(true);
        	}

        	// 세부 카테고리 콤보박스
        	cbCategory.setSelectedItem(subCategory);

        	// 소비 명
        	tfTitle.setText(title);

        	// 지출 금액
            int unformattedAmount = LedgerData.parseCurrency(amountStr);
            tfAmount.setText(String.valueOf(unformattedAmount));
        } catch (Exception ex) {	}
    }

    // 추가 버튼
    private void onAddRow(ActionEvent e) {
    	
    	String year = tfYear.getText().trim();
        String month = tfMonth.getText().trim();
        String day = tfDay.getText().trim();
        
        // 날짜를 두 자리로 맞춤 (5 -> 05)
        if (month.length() == 1) month = "0" + month;
        if (day.length() == 1) day = "0" + day;
                
        String date = year + "-" + month + "-" + day;	// DB 저장용
        
        String categoryType = rbNeed.isSelected() ? "필수" : "선택";
        String subCategory = (String) cbCategory.getSelectedItem();
        String title = tfTitle.getText().trim();
        String amountStr = tfAmount.getText().trim();
        
     
  
        if (title.isEmpty() || amountStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "내용과 금액을 입력하세요.");
            return;
        }
        
        try {
            // 금액 유효성 검사
            long checkAmount = Long.parseLong(amountStr);

            // int의 최대값을 넘는지 확인
            if (checkAmount > 2100000000) {
                JOptionPane.showMessageDialog(this, "입력한 금액이 너무 큽니다. (최대 21억)", "입력 오류", JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            // DB 저장 및 데이터 갱신 담당
            Object[] rowData = {date, categoryType, subCategory, title, amountStr, 0};
            data.addExpenseRow(rowData);
            
            resetInputFields();	// 입력 필드 초기화
            
            // 다른 탭(설정, 분석 등)에도 변경 알림
            updateCallback.run();
            
            // 과소비 기준 충족 여부 확인하여 알림 표시
            settingsTab.checkOverspendingAlert();
            
        } catch (NumberFormatException ex) {
        	// 입력이 숫자가 아닐 때 알림
            JOptionPane.showMessageDialog(this, "유효한 숫자를 입력해주세요.", "입력 오류", JOptionPane.WARNING_MESSAGE);
            return;
        }
    }
    
    // 수정 버튼
    private void onEditRow(ActionEvent e) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "수정할 행을 선택하세요.");
            return;
        }
        
        // 날짜 구성
        String date = String.format("%s/%s/%s", tfYear.getText().trim(), tfMonth.getText().trim(), tfDay.getText().trim());
        String categoryType = rbNeed.isSelected() ? "필수" : "선택";
        String subCategory = (String) cbCategory.getSelectedItem();
        String title = tfTitle.getText().trim();
        String amountStr = tfAmount.getText().trim();
        
        // 수정할 데이터 배열
        Object[] newData = new Object[]{date, categoryType, subCategory, title, amountStr};
        data.updateExpenseRow(selectedRow, newData);
        
        resetInputFields();
        table.clearSelection();
        updateCallback.run();
    }

    // 삭제 버튼
    private void onDeleteRow(ActionEvent e) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "삭제할 행을 선택하세요.");
            return;
        }

        // 삭제 전 알림 표시
        int confirm = JOptionPane.showConfirmDialog(this, "선택한 지출 항목을 삭제하시겠습니까?", "삭제 확인", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            data.removeExpenseRow(selectedRow);
            resetInputFields();
            updateCallback.run();
        }
    }
    
    // 테이블 ui를 수동으로 갱신할 때 호출
    public void updateExpenseTable() {
        // 테이블 UI를 다시 그립니다.
        if (table != null) {
            table.revalidate();
            table.repaint();
        }
    }
    
    // 입력 필드 초기화
    private void resetInputFields() {
        LocalDate today = LocalDate.now();
        // 날짜 필드 초기화
        tfYear.setText(String.valueOf(today.getYear()));
        tfMonth.setText(String.valueOf(today.getMonthValue()));
        tfDay.setText(String.valueOf(today.getDayOfMonth()));

        rbNeed.setSelected(true); // 필수가 기본
        tfTitle.setText("");
        tfAmount.setText("");
    }
}