package javaTeam3;

// DB 데이터 관리
public class DBdata {
	// DB와 연동하기위한 변수
	private int id;             // 고유 번호(수정 삭제 시 필요)
    private String clientId;    // 사용자 ID
    private String date;        // 날짜
    private String type;        // 필수, 선택
    private String category;    // 카테고리
    private String title;       // 내용
    private int amount;         // 금액
	
	// 데이터를 불러올 때 쓰는 생성자
    public DBdata(int id, String clientId, String date, String type, String category, String title, int amount) {
        this.id = id;
        this.clientId = clientId;
        this.date = date;
        this.type = type;
        this.category = category;
        this.title = title;
        this.amount = amount;
    }
    
    // 데이터를 저장할 때 쓰는 생성자
    public DBdata(String clientId, String date, String type, String category, String title, int amount) {
        this.clientId = clientId;
        this.date = date;
        this.type = type;
        this.category = category;
        this.title = title;
        this.amount = amount;
    }
	
    // DB Getter메서드 (외부에서 값을 꺼낼 때 사용)
    public int getId() { return id; }
    public String getClientId() { return clientId; }
    public String getDate() { return date; }
    public String getType() { return type; }
    public String getCategory() { return category; }
    public String getTitle() { return title; }
    public int getAmount() { return amount; }
}
